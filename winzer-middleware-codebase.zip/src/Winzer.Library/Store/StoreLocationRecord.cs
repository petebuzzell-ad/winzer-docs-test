namespace Winzer.Library.Store;

public class StoreLocationRecord
{
    public string StoreId { get; set; } = String.Empty;
    public string LocationId { get; set; } = String.Empty;
}
