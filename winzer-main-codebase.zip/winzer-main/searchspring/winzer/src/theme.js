export const customTheme = {
  // components: {
  // 	button: {
  // 		color: '#3a23ad',
  // 	},
  // 	icon: {
  // 		color: '#00cee1',
  // 	},
  // 	price: {
  // 		decimalPlaces: 0,
  // 		symbol: '€',
  // 		symbolAfter: true,
  // 	},
  // },
};
