import { h } from 'preact'
export const SortArrow = () => {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" width="6" height="4" viewBox="0 0 6 4" fill="none">
        <path d="M0 0L3 4L6 0H0Z" fill="white"/>
      </svg>
    )
}
